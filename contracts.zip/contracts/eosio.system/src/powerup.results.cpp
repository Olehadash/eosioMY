#include <eosio.system/powerup.results.hpp>

void powup_results::powupresult( const asset& fee, const int64_t powup_net_weight, const int64_t powup_cpu_weight ) { }

extern "C" void apply( uint64_t, uint64_t, uint64_t ) { }
